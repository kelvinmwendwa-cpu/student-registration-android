# Student Registration and Management — Android Studio

Java + XML Android app for university mobile programming practicals. Includes welcome page with supplied profile photograph, registration form, validation, offline SQLite storage, searchable student list, edit and delete.

## Open
1. Extract ZIP.
2. Android Studio > Open > select `StudentRegistrationAndroid` folder (the one with `settings.gradle`).
3. Allow Gradle sync; ensure JDK 17 and Android SDK Platform 35 are installed.
4. Run on an emulator or Android phone.

## Important
- This is a new standalone project because your existing Android Studio project was not uploaded.
- No internet or login is needed. Student records are stored on the device.
- The profile photograph is included in `app/src/main/res/drawable/profile_photo.jpg`. Remove it before sharing the app if you want privacy.
- SQLiteOpenHelper is used instead of Room to keep the classroom project easy to understand. Fragments are used; MVVM is not yet implemented.
- The project has not been compiled in this environment because Android SDK/Gradle are not installed here. Run Gradle sync/build locally and share any errors for fixes.
- If Android Studio asks for a Gradle distribution, choose Gradle 8.7 (compatible with Android Gradle Plugin 8.6.1).

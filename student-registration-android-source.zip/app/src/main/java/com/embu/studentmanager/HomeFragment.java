package com.embu.studentmanager;
import android.os.Bundle;import android.view.*;import androidx.annotation.*;import androidx.fragment.app.Fragment;
public class HomeFragment extends Fragment {
 @Nullable @Override public View onCreateView(@NonNull LayoutInflater i,@Nullable ViewGroup c,@Nullable Bundle b){View v=i.inflate(R.layout.fragment_home,c,false);MainActivity a=(MainActivity)requireActivity();v.findViewById(R.id.goRegister).setOnClickListener(x->a.form(null));v.findViewById(R.id.goRecords).setOnClickListener(x->a.list());return v;}
}

package com.embu.studentmanager;
import android.os.Bundle;import androidx.appcompat.app.AppCompatActivity;import androidx.fragment.app.Fragment;
public class MainActivity extends AppCompatActivity {
 StudentDb db;
 @Override protected void onCreate(Bundle state){super.onCreate(state);setContentView(R.layout.activity_main);db=new StudentDb(this);if(state==null)show(new HomeFragment(),false);}
 void show(Fragment f,boolean back){androidx.fragment.app.FragmentTransaction tx=getSupportFragmentManager().beginTransaction().replace(R.id.container,f);if(back)tx.addToBackStack(null);tx.commit();}
 void form(Student s){show(FormFragment.create(s),true);} void list(){show(new ListFragment(),true);}
}

package com.embu.studentmanager;
import android.content.*;import android.database.*;import android.database.sqlite.*;import java.util.*;
public class StudentDb extends SQLiteOpenHelper {
 public StudentDb(Context c){super(c,"students.db",null,1);}
 @Override public void onCreate(SQLiteDatabase db){db.execSQL("CREATE TABLE students(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,reg TEXT NOT NULL UNIQUE,email TEXT NOT NULL,phone TEXT NOT NULL,course TEXT NOT NULL,year TEXT NOT NULL,gender TEXT NOT NULL)");}
 @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion){}
 public boolean save(Student s){ContentValues v=new ContentValues();v.put("name",s.name);v.put("reg",s.reg);v.put("email",s.email);v.put("phone",s.phone);v.put("course",s.course);v.put("year",s.year);v.put("gender",s.gender);try {if(s.id==0)return getWritableDatabase().insertOrThrow("students",null,v)>0;return getWritableDatabase().update("students",v,"id=?",new String[]{String.valueOf(s.id)})>0;}catch(SQLiteConstraintException e){return false;}}
 public ArrayList<Student> all(String search){ArrayList<Student> list=new ArrayList<>();String q="%"+search+"%";try(Cursor c=getReadableDatabase().query("students",null,"name LIKE ? OR reg LIKE ?",new String[]{q,q},null,null,"name COLLATE NOCASE ASC")){while(c.moveToNext())list.add(new Student(c.getLong(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("name")),c.getString(c.getColumnIndexOrThrow("reg")),c.getString(c.getColumnIndexOrThrow("email")),c.getString(c.getColumnIndexOrThrow("phone")),c.getString(c.getColumnIndexOrThrow("course")),c.getString(c.getColumnIndexOrThrow("year")),c.getString(c.getColumnIndexOrThrow("gender"))));}return list;}
 public void delete(long id){getWritableDatabase().delete("students","id=?",new String[]{String.valueOf(id)});}
}

package com.embu.studentmanager;
public class Student {
 public long id; public String name, reg, email, phone, course, year, gender;
 public Student(long id,String name,String reg,String email,String phone,String course,String year,String gender){this.id=id;this.name=name;this.reg=reg;this.email=email;this.phone=phone;this.course=course;this.year=year;this.gender=gender;}
}

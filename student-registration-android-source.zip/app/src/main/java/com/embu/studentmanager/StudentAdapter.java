package com.embu.studentmanager;
import android.view.*;import android.widget.*;import androidx.annotation.NonNull;import androidx.recyclerview.widget.RecyclerView;import java.util.*;
public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.Holder> {
 interface Actions {void edit(Student s);void delete(Student s);}
 private ArrayList<Student> data;private final Actions actions;
 StudentAdapter(ArrayList<Student> d,Actions a){data=d;actions=a;}
 void update(ArrayList<Student> d){data=d;notifyDataSetChanged();}
 @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup p,int type){return new Holder(LayoutInflater.from(p.getContext()).inflate(R.layout.row_student,p,false));}
 @Override public void onBindViewHolder(@NonNull Holder h,int pos){Student s=data.get(pos);h.title.setText(s.name+" • "+s.reg);h.details.setText(s.course+" | Year "+s.year+"\n"+s.email+"\n"+s.phone+" | "+s.gender);h.edit.setOnClickListener(v->actions.edit(s));h.delete.setOnClickListener(v->actions.delete(s));}
 @Override public int getItemCount(){return data.size();}
 static class Holder extends RecyclerView.ViewHolder{TextView title,details;Button edit,delete;Holder(View v){super(v);title=v.findViewById(R.id.rowTitle);details=v.findViewById(R.id.rowDetails);edit=v.findViewById(R.id.editStudent);delete=v.findViewById(R.id.deleteStudent);}}
}
